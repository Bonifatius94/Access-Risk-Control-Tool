=====================================
====== ABOUT THIS APPLICATION =======
=====================================

This is a group project made by students of the university of Augsburg.
Creators: Merlin Albes, Marco Tr�ster, Franz Schulze, Stefan Jung and Joshua Schreibeis.

The AccessRiskControlTool (ART) is designed to find critical violations in a given SAP right system.

=====================================
===== INSTALLATION INSTRUCTIONS =====
=====================================

1. Install VC++ 2005 runtime. (only required for Windows)
2. Install JRE 8 Update 172 (use exactly this JRE and also remove any other JRE from your machine if possible)
3. Then run the AccessRiskTool.jar file which will guide you through the setup