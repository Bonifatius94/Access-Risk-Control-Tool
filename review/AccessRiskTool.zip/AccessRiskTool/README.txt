=====================================
====== ABOUT THIS APPLICATION =======
=====================================

This is a group project made by students of the university of Augsburg.
Creators: Merlin Albes, Marco Tr�ster, Franz Schulze, Stefan Jung and Joshua Schreibeis.

The AccessRiskControlTool (ART) is designed to find critical violations in a given SAP right system.

=====================================
===== INSTALLATION INSTRUCTIONS =====
=====================================

1. Install VC++ 2005 runtime.
2. Install JRE 8 Update 172 (NOT Java 10!).
3. Then run the application jar file which will guide you through the setup.